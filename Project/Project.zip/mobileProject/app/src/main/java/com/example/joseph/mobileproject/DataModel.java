package com.example.joseph.mobileproject;

/**
 * Created by Joseph on 11/17/17.
 */

public class DataModel {

    public int icon;
    public String name;

    // Constructor.
    public DataModel(int icon, String name) {

        this.icon = icon;
        this.name = name;
    }
}